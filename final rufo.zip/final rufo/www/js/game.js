var w = 800, h = 600;
var menuText;
var playText;
var aboutText;
var tionText;
var platform, player, keyboard,ai,ais,ai1,ai1s,ai2,ai2s, stateText,buttonIkap,hi,scoreInterval,over,line,line2;
var a = 0, b = 3;
var goButton;
var restart;
var scoreText;
var score=0;
var buttonUp;
var buttonRight;
var buttonDown;
var buttonLeft;
var speed = 1000;
var tween;
// var win;
// var y1, y2;
var game = new Phaser.Game(w, h, Phaser.CANVAS, '');

game.state.add("bootGame",bootGame);
game.state.add("preloadGame",preloadGame);
game.state.add("menuGame",menuGame);
game.state.add("playGame",playGame);
game.state.add("winGame",winGame);
game.state.add("loseGame",loseGame);

game.state.start("bootGame");