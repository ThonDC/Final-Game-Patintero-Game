
bootGame = {

		create:function(){
				game.physics.startSystem(Phaser.Physics.ARCADE);

				game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    			game.scale.forceLascape = true;
    			game.scale.pageAlignHorizontally = true;
   				game.scale.pageAlignVertically = true;
    			//game.world.setBounds(0,0,800,1200);
			
				game.state.start("preloadGame");
				keyboard = game.input.keyboard.createCursorKeys();
		}
}

preloadGame = {
	preload: function(){
		game.load.image('back', 'img/backgame.png');
        game.load.image('bg','img/ground.png');
        game.load.image('menu','img/menu.png');
        game.load.image('play', 'img/PlayBtn.png');
        game.load.image('about', 'img/about.png')
        game.load.image('tion', 'img/tion.png')
        game.load.image('instruction', 'img/instruction.png')
        game.load.image('aboutus', 'img/aboutus.png')
        game.load.image('gameover', 'img/gameover.png');
        game.load.image('ground','img/platform.png');
        game.load.image('ground','img/platform2.png');
        // game.load.image('play','img/play.png');
        game.load.image('line','img/line.png');
        game.load.image('line2','img/line2.png');
        game.load.image('win','img/win.png');
        game.load.image('lose','img/lose.png');

        game.load.spritesheet('farmer1','img/farmer.png',50,50);
        game.load.spritesheet('ai', 'img/samlpe.png',100,100);
        game.load.spritesheet('ai2', 'img/samlpe1.png',100,100);
        game.load.spritesheet('ai3', 'img/samlpe2.png',100,100);
        game.load.spritesheet('buttonIkap','img/pause2.png',50,50);
        game.load.spritesheet('btn-left','img/left.png');
        game.load.spritesheet('btn-right','img/right.png');
        game.load.spritesheet('btn-up','img/up.png');
        game.load.spritesheet('btn-down','img/down.png');
        game.load.image('pbg','img/ground.png');

        game.load.audio('per','audio/percussion.mp3');
        game.load.audio('kansyonwin','audio/clapping.mp3');
        game.load.audio('kansyonlose','audio/player_death.mp3');


	},

	create:function(){
		game.state.start("menuGame");
	}
}

menuGame = {
	create:function(){

		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    	game.scale.forcePortrait = true;
    	game.scale.forceLandscape = false;
    	game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();  
        
		//game.stage.backgroundColor = "#DCDCDC";
		
		menu = game.add.image(0,0,'menu');
        per =game.add.audio("per");
        per.play();
		// home.scale.set(1.4);

		pbtn = game.add.button(w/2,390,"play",this.lundag);
		pbtn.anchor.set(0.5);

		about = game.add.button(w/2,460,"about",this.aboutGame);
		about.anchor.set(0.5);

        tion = game.add.button(397,530,"tion",this.tionGame);
        tion.anchor.set(0.5);
		
 

		console.log("current state: menu");

	},
	update:function(){
			// if(keyboard.up.isDown){
			// 	game.state.start("playGame");
			// }
	},
	lundag:function (){
		game.state.start("playGame");
   },
   aboutGame: function(){
        game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    	game.scale.forcePortrait = true;
    	game.scale.forceLandscape = false;
    	game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();

            about=game.add.image(0,0,"aboutus");
            // about.scale.set(1.4);
            backButton=game.add.button(600,550,"back",backB,this);
            backButton.scale.set(0.5);

            
             function backB() {
        	about.visible =! backButton.visible;
        	backButton.destroy();

            game.state.start("menuGame");
       		 // window.location.href=window.location.href;
            }

           
        },
        tionGame: function(){
             tion=game.add.image(0,0,"instruction");
            // about.scale.set(1.4);
            backButton=game.add.button(600,550,"back",backB,this);
            backButton.scale.set(0.5);

            function backB() {
            tion.visible =! backButton.visible;
            backButton.destroy();

            game.state.start("menuGame");
             // window.location.href=window.location.href;
            }
    },
};


playGame = {

	create: function(){
		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
 
    	game.scale.forcePortrait = false;
    	game.scale.forceLandscape = true;
    	game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();

        kansyonlose =game.add.audio("kansyonlose");
        kansyonwin =game.add.audio("kansyonwin");

        per =game.add.audio("per");
        per.play();


		bg = game.add.image(0,0,'pbg')

		over = game.add.text(90,300,'Game Over!',{font: '200px Chiller',fill:'red'});
    	over.visible = false;

    	win = game.add.text(70,300,'You Win!',{font: '150px Serif',fill:'blue'});
    	win.visible = false;
    
    line = game.add.sprite(60,60,"line");
    
    line2 = game.add.sprite(730,80,"line2");
    game.physics.arcade.enable(line2);

    line2.body.immovable = true;
   
    player = game.add.sprite(40,270,'farmer1'); 
    keyboard = game.input.keyboard.createCursorKeys();

    buttonRight = game.add.button(700,400,"btn-right",patentiro.rightFarmer1);
    buttonLeft = game.add.button(600,400,"btn-left",patentiro.leftFarmer1);
    buttonUp = game.add.button(650,350,"btn-up",patentiro.upFarmer1);
    buttonDown = game.add.button(650,450,"btn-down",patentiro.downFarmer1);
    
     ai = game.add.sprite(85,80,'ai');
    // ai.animations.add('ai',[0,],6,true);

    ai2 = game.add.sprite(373,80,'ai2');
    // ai2.animations.add('ai2',[0,],6,true);

    ai3 = game.add.sprite(672,80,'ai3');
    // ai3.animations.add('ai3',[0,],6,true);

    platforms = game.add.group(); 
    ledge = platforms.create(0, 525, 'ground');
    game.physics.arcade.enable(ledge);
    ledge.body.immovable=true;
    ledge.scale.x = 5;

    platform2s = game.add.group(); 
    ledge2 = platform2s.create(0, 50, 'ground');
    game.physics.arcade.enable(ledge2);
    ledge2.body.immovable=true;
    ledge2.scale.x = 5;

    
 
    game.physics.arcade.enable(player);
    player.body.collideWorldBounds = true;
    player.body.gravity.y = 0;
    game.physics.arcade.enable(ai);
    ai.body.collideWorldBounds = true;
    ai.body.velocity.y=-300;
    ai.body.bounce.y=1;

    game.physics.arcade.enable(ai2);
    ai2.body.collideWorldBounds = true;
    ai2.body.velocity.y=-400;
    ai2.body.bounce.y=1;

    game.physics.arcade.enable(ai3);
    ai3.body.collideWorldBounds = true;
    ai3.body.velocity.y=-500;
    ai3.body.bounce.y=1;

    buttonIkap = game.add.button(10,16,"buttonIkap",patentiro.PlayPause);
    // buttonPlay = game.add.button(0,0,'play',patentiro.play);
    

    stateText = game.add.text(game.world.centerX,game.world.centerY,' ', { font: '90px Comic Sans MS', fill: 'black' });
    stateText.anchor.setTo(0.5, 0.5);
    stateText.visible = false;
	},
	update: function(){
		//game.physics.arcade.overlap(taya,kalaro1,Kalaro2,Kalaro3,Kalaro4,Kalaro5);
		if (game.physics.arcade.collide(ai,player)){
        game._paused=true
        kansyonlose.play();
        // over.visible =true;
        lose = game.add.sprite(0,0,'lose');
        patentiro.restart.visible = true;
                stateText.text="Tap to restart";
                stateText.visible = true;
                game.input.onTap.addOnce(patentiro.restart,this);

    }
    if (game.physics.arcade.collide(ai2,player)){
        game._paused=true
        kansyonlose.play();
        lose = game.add.sprite(0,0,'lose');
        patentiro.restart.visible = true;
                stateText.text="Tap to restart";
                stateText.visible = true;
                game.input.onTap.addOnce(patentiro.restart,this);

    }
    if (game.physics.arcade.collide(ai3,player)){
        game._paused=true
        kansyonlose.play();
        lose = game.add.sprite(0,0,'lose');
        patentiro.restart.visible = true;
        
        score.visible=true
                stateText.text="Tap to restart";
                stateText.visible = true;
                game.input.onTap.addOnce(patentiro.restart,this);

    }
     if (game.physics.arcade.collide(line,player)){
        game._paused=true
        kansyonwin.play();
        win = game.add.sprite(0,0,'win');
        // patentiro.restart.visible = true;
        // hi.visible=true;
        // score.visible=true
                stateText.text="Tap to play again";
                stateText.visible = true;
                game.input.onTap.addOnce(patentiro.restart,this);

    }
     if (game.physics.arcade.collide(line2,player)){
        // game._paused=true
        // win.visible =true;
        // patentiro.restart.visible = true;
        // hi.visible=true;
        // score.visible=true
       game.physics.arcade.enable(line);
       line.body.immovable = true;
                // stateText.text="nice one!";
                // stateText.visible = true;

                // game.input.onTap.addOnce(patentiro.restart,this);

    }

        game.physics.arcade.collide(ledge,player);
        game.physics.arcade.collide(ledge2,player);
        game.physics.arcade.collide(ledge,ai);
        game.physics.arcade.collide(ledge2,ai);
        game.physics.arcade.collide(ledge,ai2);
        game.physics.arcade.collide(ledge2,ai2);
        game.physics.arcade.collide(ledge,ai3);
        game.physics.arcade.collide(ledge2,ai3);
        game.physics.arcade.collide(player,line,patentiro.touchLine);
        game.physics.arcade.collide(player,line2,patentiro.touchLine2);

        game.physics.arcade.overlap(ai,player,patentiro.killAi);
        game.physics.arcade.overlap(ai2,player,patentiro.killAi2);
        game.physics.arcade.overlap(ai3,player,patentiro.killAi3);
        // game.physics.arcade.overlap(player,ai2,patentiro.killAi2);
        // game.physics.arcade.overlap(player,ai3,patentiro.killAi3);

        console.log("x: "+Math.round(player.body.position.x));
        console.log("y: "+Math.round(player.body.position.y));

        if(Math.round(player.body.position.x)>=game.width/2)
            ai.body.position.y = Math.round(player.body.position.y);
        
        player.body.velocity.x = 0;
		player.body.velocity.y = 0;
      	//    player.animations.add('walk-right',[0],0,true);
    	 // player.animations.add('walk-left',[0],0,true);
    	 // player.animations.add('walk-up',[0],0,true);
    	 // player.animations.add('walk-down',[0],0,true);

        if(keyboard.up.isDown){
            player.body.velocity.y = -speed;
            // platform2.body.velocity.y = -speed;
            player.body.position.x = 10;
            // platform2.body.position.x = w-50;
        }
        else if(keyboard.down.isDown){
            player.body.velocity.y = speed;
            // platform2.body.velocity.y = speed;
            player.body.position.x = 10;
            // platform2.body.position.x = w-50;
        }
        else if(keyboard.left.isDown){
            player.body.velocity.x = -500;
            // platform2.body.velocity.x = -500;
        }
        else if(keyboard.right.isDown){
            player.body.velocity.x = 500;
            // platform2.body.velocity.x = 500;
        }
        else{   
            player.body.velocity.y = 0;
            // platform2.body.velocity.y = 0;
            player.body.velocity.x = 0;
            // platform2.body.velocity.x = 0;
        }


        if(Math.round(player.body.position.x)>=game.width/1.5)
            ai2.body.position.y = Math.round(player.body.position.y);

        if(keyboard.up.isDown){
            player.body.velocity.y = -speed;
            // platform2.body.velocity.y = -speed;
            player.body.position.x = 10;
            // platform2.body.position.x = w-50;
        }
        else if(keyboard.down.isDown){
            player.body.velocity.y = speed;
            // platform2.body.velocity.y = speed;
            player.body.position.x = 10;
            // platform2.body.position.x = w-50;
        }
        else if(keyboard.left.isDown){
            player.body.velocity.x = -500;
            // platform2.body.velocity.x = -500;
        }
        else if(keyboard.right.isDown){
            player.body.velocity.x = 500;
            // platform2.body.velocity.x = 500;
        }
        else{   
            player.body.velocity.y = 0;
            // platform2.body.velocity.y = 0;
            player.body.velocity.x = 0;
            // platform2.body.velocity.x = 0;
        }

        if(Math.round(player.body.position.x)>=game.width/0.9)
            ai3.body.position.y = Math.round(player.body.position.y);

        if(keyboard.up.isDown){
            player.body.velocity.y = -speed;
            // platform2.body.velocity.y = -speed;
            player.body.position.x = 10;
            // platform2.body.position.x = w-50;
        }
        else if(keyboard.down.isDown){
            player.body.velocity.y = speed;
            // platform2.body.velocity.y = speed;
            player.body.position.x = 10;
            // platform2.body.position.x = w-50;
        }
        else if(keyboard.left.isDown){
            player.body.velocity.x = -500;
            // platform2.body.velocity.x = -500;
        }
        else if(keyboard.right.isDown){
            player.body.velocity.x = 500;
            // platform2.body.velocity.x = 500;
        }
        else{   
            player.body.velocity.y = 0;
            // platform2.body.velocity.y = 0;
            player.body.velocity.x = 0;
            // platform2.body.velocity.x = 0;
        }



        

    if(keyboard.left.isDown){
        player.body.velocity.x = -300;
        
    }
    else if(keyboard.right.isDown){
        player.body.velocity.x = 300;
        
    }
    else if(keyboard.up.isDown){
        player.body.velocity.y = -400;
    }
    else if(keyboard.down.isDown){
        player.body.velocity.y = 400;
    }
    // else {
    //  player.body.velocity.x = 0;
    //  player.body.velocity.y = 0;
    //  player.animations.stop();
    // }
    if(keyboard.up.isDown && player.body.touching.down){
        player.body.velocity.y = -500; 
     }

    //     if (cursors.left.isDown)
    // {
    //     taya.angle -= 4;
    // }
    // else if (cursors.right.isDown)
    // {
    //     taya.angle += 4;
    // }

    // if (cursors.up.isDown)
    // {
    //     //  The speed we'll travel at
    //     currentSpeed = 100;
    // }
    // else
    // {
    //     if (currentSpeed > 0)
    //     {
    //         currentSpeed -= 4;
    //     }
    // }

    // if (currentSpeed > 0)
    // {
    //     game.physics.arcade.velocityFromRotation(taya.rotation, currentSpeed,taya.body.velocity);
    // }
		// land.tilePosition.x = -game.camera.x;
  //   	land.tilePosition.y = -game.camera.y;
	}
};
//game.state.add('Play', BasicGame, true);
//}
       var patentiro = function(){
    "use strict";
    return {  
        // play:function(){
        //     buttonPlay.destroy();
        // },

// touchLine:function (player,line){

//         score  += 1;
//         scoreText.text = 'Score:  ' + score;
//         //player.body.position=900
// },
// touchLine2:function (player,line2){

//         score  += 1;
//         scoreText.text = 'Score:  ' + score;
// },

leftFarmer1: function() {
        // buttonLeft.frame = 1;
        // player.animations.play('walk-left');
        player.body.velocity.x = -1500;
        
    
    // setTimeout(function(){
    //     buttonLeft.frame = 0;
    //     player.body.velocity.x = 0;
    //     player.animations.stop();
    // },100)
},
        rightFarmer1: function(){
        // buttonRight.frame = 1;
        player.body.velocity.x = 1500;
        // player.animations.play('walk-right');
        
    // setTimeout(function(){
    //     buttonRight.frame = 0;
    //     player.body.velocity.x = 0;
    //     player.animations.stop();
    // },100)
},
        upFarmer1: function() {
        // buttonUp.frame = 1;
        player.body.velocity.y =-900;
        // player.animations.play('walk-up');
        
        // setTimeout(function(){
        // buttonUp.frame = 0;
        // player.body.velocity.x = 0;
        // player.animations.stop();
        // },100)
},
        downFarmer1: function() {
        // buttonDown.frame = 1;
        player.body.velocity.y = 900;
        // player.animations.play('walk-down');
        
        // setTimeout(function(){
        // buttonDown.frame = 0;
        // player.body.velocity.x = 0;
        // player.animations.stop();
        // },100)
},
PlayPause: function(){
                buttonIkap.frame = 1;
                game._paused = true;

                setTimeout(function(){
                buttonIkap.frame = 0;
                },100);

                setTimeout(function(){
                game._paused = false;
                },3000);
                },
restart: function() {
    window.location.href=window.location.href;
    stateText.visible = false;
},
saveScore: function(score){
    localStorage.setItem("gameScore",score);
},

getScore: function(){
    return (localStorage.getItem("gameScore") == null || localStorage.getItem("gameScore") == "")?0:localStorage.getItem("gameScore");
},
           }
            }();




	
winGame = {
	preload:function(){

	},

	create:function(){

	},

	update:function(){

	}
}

loseGame = {
	preload:function(){

	},

	create:function(){

	},

	update:function(){

	}
}